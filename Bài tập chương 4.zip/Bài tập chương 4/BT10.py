def concatenate_dictionaries(dic1, dic2):
    """
    Nối (concatenate) hai từ điển. Nếu có khóa trùng, giá trị của dic2 sẽ được giữ lại.
    Sử dụng toán tử giải nén (unpacking) ** cho Python 3.9+
    """
    # Cách 1: Sử dụng toán tử giải nén (**), đây là cách hiện đại và ngắn gọn nhất
    result = {**dic1, **dic2}
    
    # Cách 2: Sử dụng phương thức copy() và update() (tương thích rộng hơn)
    # result = dic1.copy()
    # result.update(dic2)
    
    return result

# Ví dụ minh họa:
dic1 = {1: 10, 2: 20}
dic2 = {3: 30, 4: 40}
dic3 = {2: 50, 5: 60} # Ví dụ có khóa trùng (khóa 2)

print(f"dic1: {dic1}")
print(f"dic2: {dic2}")
print(f"Kết quả nối dic1 và dic2: {concatenate_dictionaries(dic1, dic2)}")
print(f"Kết quả nối dic1 và dic3 (khóa 2 trùng): {concatenate_dictionaries(dic1, dic3)}")