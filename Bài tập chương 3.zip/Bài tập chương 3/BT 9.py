def kiem_tra_cccd(cccd):
    if len(cccd) == 12 and cccd.isdigit():
        print("CCCD hợp lệ")
    else:
        print("CCCD không hợp lệ")

# Ví dụ:
cccd = input("Nhập CCCD: ")
kiem_tra_cccd(cccd)


