import math

def uoc(n):
    # trả về danh sách ước dương của n
    res = []
    for i in range(1, int(math.sqrt(n))+1):
        if n % i == 0:
            res.append(i)
            if i != n//i:
                res.append(n//i)
    return sorted(res)

def so_luong_uoc_nguyen_to_khac_nhau(n):
    # tìm các ước là số nguyên tố, đếm
    def is_prime(p):
        if p < 2: return False
        if p % 2 == 0:
            return p == 2
        r = int(math.sqrt(p))
        for i in range(3, r+1, 2):
            if p % i == 0:
                return False
        return True
    return sum(1 for d in uoc(n) if is_prime(d))

def tong_uoc_thuc_su(n):
    return sum(uoc(n)) - n

def tong_binh(n):
    return n*(n+1)*(2*n+1)//6


