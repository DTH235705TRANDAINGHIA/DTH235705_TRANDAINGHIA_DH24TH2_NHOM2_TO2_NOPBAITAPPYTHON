def bai17(n):
    # a) 1 + 2 + ... + 2n = (2n)(2n+1)/2 = n(2n+1)
    a = n * (2*n + 1)
    # b) các số tự nhiên < n và lẻ: sum of odd numbers from 1 to n-1 (odd)
    b = sum(i for i in range(1, n) if i % 2 == 1)
    # c) các số tự nhiên < n và chẵn
    c = sum(i for i in range(1, n) if i % 2 == 0)
    return a, b, c


