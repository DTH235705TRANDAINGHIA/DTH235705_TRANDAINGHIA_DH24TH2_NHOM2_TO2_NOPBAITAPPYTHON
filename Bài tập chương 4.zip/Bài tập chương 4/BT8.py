def dict_value_summary(my_dict):
    """
    Tính tổng và tích các giá trị (value) trong từ điển, giả sử các giá trị là số.
    """
    if not my_dict:
        return 0, 1
        
    values = [v for v in my_dict.values() if isinstance(v, (int, float))]
    
    if not values:
        print("Từ điển không có giá trị dạng số.")
        return 0, 1

    total_sum = sum(values)
    
    total_product = 1
    for value in values:
        total_product *= value
        
    return total_sum, total_product

# Ví dụ sử dụng:
my_dictionary = {'a': 10, 'b': 2, 'c': 5, 'd': 'x', 1: 3}
dict_sum, dict_product = dict_value_summary(my_dictionary)

print(f"8) Từ điển: {my_dictionary}")
print(f"Tổng các giá trị dạng số (10+2+5+3): **{dict_sum}**")
print(f"Tích các giá trị dạng số (10*2*5*3): **{dict_product}**")
print("\n")