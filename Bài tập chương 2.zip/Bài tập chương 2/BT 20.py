import math

def max_prime_divisor_of_gcd(m, n):
    g = math.gcd(m, n)
    if g <= 1:
        return 0
    maxp = 0
    # kiểm tra 2
    while g % 2 == 0:
        maxp = 2
        g //= 2
    p = 3
    while p * p <= g:
        while g % p == 0:
            maxp = p
            g //= p
        p += 2
    if g > 1:
        maxp = max(maxp, g)
    return maxp if maxp != 0 else 0

# Ví dụ:
print(max_prime_divisor_of_gcd(48, 18))  # gcd=6, prime divisors 2 and 3 -> trả 3
print(max_prime_divisor_of_gcd(8, 9))    # gcd=1 -> 0
