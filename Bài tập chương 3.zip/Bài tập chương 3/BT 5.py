# Câu 5: Kiểm tra 1 chuỗi có phải là chuỗi đối xứng hay không.

s = input("Nhập chuỗi: ")
if s == s[::-1]:
    print("Chuỗi đối xứng.")
else:
    print("Chuỗi không đối xứng.")
