import re

def NegativeNumberInStrings(s):
    so_am = re.findall(r'-\d+', s)
    return [int(x) for x in so_am]

chuoi = input("Nhập chuỗi: ")
print("Các số nguyên âm là:", NegativeNumberInStrings(chuoi))
