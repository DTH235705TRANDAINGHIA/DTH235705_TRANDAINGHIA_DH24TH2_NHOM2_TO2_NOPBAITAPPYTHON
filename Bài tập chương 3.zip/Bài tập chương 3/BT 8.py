# Câu 8: Nhập 2 chuỗi s1, s2. Kiểm tra s2 có trong s1 không, nếu có thì in vị trí đầu tiên.

s1 = input("Nhập chuỗi s1: ")
s2 = input("Nhập chuỗi s2: ")

index = s1.find(s2)
if index != -1:
    print(f"Chuỗi '{s2}' xuất hiện lần đầu tại vị trí {index}")
else:
    print("Không tìm thấy chuỗi con.")
