def hop_le(pw):
    if (6 <= len(pw) <= 12 and
        any(c.islower() for c in pw) and
        any(c.isupper() for c in pw) and
        any(c.isdigit() for c in pw) and
        any(c in "$#@" for c in pw)):
        return True
    return False

nhap = input("Nhập các mật khẩu, cách nhau bởi dấu phẩy: ")
matkhaus = nhap.split(',')

hop_le_list = [pw for pw in matkhaus if hop_le(pw)]
print("Mật khẩu hợp lệ:", ",".join(hop_le_list))
