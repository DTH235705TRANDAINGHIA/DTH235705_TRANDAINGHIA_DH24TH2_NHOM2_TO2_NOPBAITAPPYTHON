# Bội của 3: i % 3 == 0. Nhỏ hơn 100: i < 100.
bo_i_cua_3 = [i for i in range(1, 100) if i % 3 == 0]
print(f"4a) Bội của 3 (<100): {bo_i_cua_3}")