class SoHoc:
    def __init__(self):
        self._number1 = 0
        self._number2 = 0

    # a. Các phương thức get/set (sử dụng @property)
    @property
    def number1(self):
        return self._number1

    @number1.setter
    def number1(self, value):
        self._number1 = value

    @property
    def number2(self):
        return self._number2

    @number2.setter
    def number2(self, value):
        self._number2 = value

    # b. InputInfo
    def inputInfo(self):
        print("\n--- Nhập 2 số ---")
        while True:
            try:
                self.number1 = float(input("Nhập number1: "))
                self.number2 = float(input("Nhập number2: "))
                break
            except ValueError:
                print("Lỗi: Vui lòng nhập số hợp lệ.")

    # c. PrintInfo
    def printInfo(self):
        print(f"Thông tin: number1 = {self.number1}, number2 = {self.number2}")

    # d. Addition
    def addition(self):
        return self.number1 + self.number2

    # e. Subtract
    def subtract(self):
        return self.number1 - self.number2

    # f. Multi
    def multi(self):
        return self.number1 * self.number2

    # g. Division
    def division(self):
        if self.number2 == 0:
            print("Lỗi: Không thể chia cho 0.")
            return None
        return self.number1 / self.number2

# Ví dụ sử dụng:
print("\n--- Lớp Số Học ---")
sh = SoHoc()
sh.inputInfo()
sh.printInfo()

print(f"Tổng (addition): {sh.addition()}")
print(f"Hiệu (subtract): {sh.subtract()}")
print(f"Tích (multi): {sh.multi()}")
print(f"Thương (division): {sh.division()}")