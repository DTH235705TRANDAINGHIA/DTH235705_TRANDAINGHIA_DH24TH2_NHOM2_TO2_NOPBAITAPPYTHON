# Sinh 10 chuỗi, từ i=0 đến i=9. Chuỗi là '1' + '0' * i
chuoi_nhi_phan_1 = ['1' + '0' * i for i in range(10)]
print(f"4c) Chuỗi nhị phân 1: {chuoi_nhi_phan_1}")