import math

def dien_tich_tron(r):
    if r < 0:
        return "Bán kính phải >= 0"
    return math.pi * r * r


