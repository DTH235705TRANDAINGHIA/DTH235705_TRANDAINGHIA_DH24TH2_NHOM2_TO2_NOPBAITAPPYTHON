from tkinter import *
from tkinter import messagebox

def giai_pt():
    try:
        a = float(txt_a.get())
        b = float(txt_b.get())
        if a == 0:
            if b == 0:
                kq.set("Phương trình vô số nghiệm")
            else:
                kq.set("Phương trình vô nghiệm")
        else:
            x = -b / a
            kq.set(f"x = {x:.2f}")
    except ValueError:
        messagebox.showerror("Lỗi", "Vui lòng nhập số hợp lệ!")

def tiep():
    txt_a.delete(0, END)
    txt_b.delete(0, END)
    kq.set("")

def thoat():
    root.destroy()

root = Tk()
root.title("PTB1")

Label(root, text="Phương Trình Bậc 1", font=("Arial", 14, "bold")).grid(row=0, column=0, columnspan=2, pady=10)

Label(root, text="Hệ số a:").grid(row=1, column=0, sticky=W)
txt_a = Entry(root)
txt_a.grid(row=1, column=1)

Label(root, text="Hệ số b:").grid(row=2, column=0, sticky=W)
txt_b = Entry(root)
txt_b.grid(row=2, column=1)

frame_btn = Frame(root)
frame_btn.grid(row=3, column=0, columnspan=2, pady=10)

Button(frame_btn, text="Giải", command=giai_pt, width=10).pack(side=LEFT, padx=5)
Button(frame_btn, text="Tiếp", command=tiep, width=10).pack(side=LEFT, padx=5)
Button(frame_btn, text="Thoát", command=thoat, width=10).pack(side=LEFT, padx=5)

kq = StringVar()
Label(root, text="Kết quả:").grid(row=4, column=0, sticky=W)
Entry(root, textvariable=kq, state='readonly', width=30).grid(row=4, column=1)

root.mainloop()