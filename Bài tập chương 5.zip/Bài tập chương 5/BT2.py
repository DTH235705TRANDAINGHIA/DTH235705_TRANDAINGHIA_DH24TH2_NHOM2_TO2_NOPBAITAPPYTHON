class HinhChuNhat:
    def __init__(self, chieu_dai, chieu_rong, mau_sac):
        self.chieu_dai = chieu_dai
        self.chieu_rong = chieu_rong
        self.mau_sac = mau_sac

    def tinhChuVi(self):
        return (self.chieu_dai + self.chieu_rong) * 2

    def tinhDienTich(self):
        return self.chieu_dai * self.chieu_rong

    def hienThiThongTin(self):
        print(f"--- Thông tin Hình Chữ Nhật ---")
        print(f"Màu sắc: {self.mau_sac}")
        print(f"Chiều dài: {self.chieu_dai}, Chiều rộng: {self.chieu_rong}")
        print(f"Chu vi: {self.tinhChuVi():.2f}")
        print(f"Diện tích: {self.tinhDienTich():.2f}")
        