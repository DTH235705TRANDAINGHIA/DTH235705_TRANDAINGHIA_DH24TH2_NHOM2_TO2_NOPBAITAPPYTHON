import math

class TamGiac:
    def __init__(self, a, b, c, mau_sac):
        # Kiểm tra tính hợp lệ của tam giác
        if not (a > 0 and b > 0 and c > 0 and (a + b > c) and (a + c > b) and (b + c > a)):
            print("Lỗi: Các cạnh không tạo thành một tam giác hợp lệ.")
            self.hop_le = False
            self.a, self.b, self.c = 0, 0, 0
        else:
            self.a = a
            self.b = b
            self.c = c
            self.hop_le = True
            
        self.mau_sac = mau_sac

    def tinhChuVi(self):
        if not self.hop_le:
            return 0
        return self.a + self.b + self.c

    def tinhDienTich(self):
        if not self.hop_le:
            return 0
        # Sử dụng công thức Heron
        p = self.tinhChuVi() / 2
        return math.sqrt(p * (p - self.a) * (p - self.b) * (p - self.c))

    def hienThiThongTin(self):
        if not self.hop_le:
            print("Đây không phải là tam giác hợp lệ.")
            return
            
        print(f"--- Thông tin Tam Giác ---")
        print(f"Màu sắc: {self.mau_sac}")
        print(f"Cạnh a: {self.a}, Cạnh b: {self.b}, Cạnh c: {self.c}")
        print(f"Chu vi: {self.tinhChuVi():.2f}")
        print(f"Diện tích: {self.tinhDienTich():.2f}")
        print(f"Loại tam giác: {self.hienThiLoai()}")

    def hienThiLoai(self):
        if not self.hop_le:
            return "Không hợp lệ"
        
        # Sử dụng math.isclose để so sánh số thực
        is_a_b = math.isclose(self.a, self.b)
        is_b_c = math.isclose(self.b, self.c)
        is_a_c = math.isclose(self.a, self.c)
        
        # Sắp xếp các cạnh để kiểm tra tam giác vuông
        canh = sorted([self.a, self.b, self.c])
        is_vuong = math.isclose(canh[0]**2 + canh[1]**2, canh[2]**2)

        if is_a_b and is_b_c:
            return "Tam giác đều"
        if is_vuong and (is_a_b or is_b_c or is_a_c):
            return "Tam giác vuông cân"
        if is_vuong:
            return "Tam giác vuông"
        if is_a_b or is_b_c or is_a_c:
            return "Tam giác cân"
        
        return "Tam giác thường"

