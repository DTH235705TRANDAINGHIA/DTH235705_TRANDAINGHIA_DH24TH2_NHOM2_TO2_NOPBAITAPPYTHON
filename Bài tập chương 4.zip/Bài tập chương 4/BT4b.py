# Bắt đầu từ 0^2 đến 19^2 (tổng cộng 20 số)
chinh_phuong = [i**2 for i in range(20)]
print(f"4b) 20 số chính phương đầu tiên: {chinh_phuong}")