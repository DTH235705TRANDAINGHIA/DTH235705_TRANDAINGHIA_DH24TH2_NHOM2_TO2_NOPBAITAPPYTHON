def in_bang_2_den_9():
    for n in range(2, 10):
        for i in range(1, 11):
            print(f"{n} * {i} = {n*i}", end='\t')
        print('\n')

in_bang_2_den_9()
