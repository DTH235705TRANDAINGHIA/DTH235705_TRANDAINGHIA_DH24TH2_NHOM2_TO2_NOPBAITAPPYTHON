import os

# Lớp này chỉ để chứa dữ liệu của MỘT môn học
class MonHoc:
    def __init__(self, ma_mon, ten_mon, so_tin_chi):
        self.ma_mon = ma_mon
        self.ten_mon = ten_mon
        self.so_tin_chi = so_tin_chi

    # Giúp việc in ra thông tin dễ dàng hơn
    def __str__(self):
        return f"| {self.ma_mon:<10} | {self.ten_mon:<25} | {self.so_tin_chi:<8} |"

# Lớp này dùng để quản lý DANH SÁCH các môn học
class QuanLyMonHoc:
    def __init__(self):
        self.danh_sach_mon_hoc = []
        self.ten_file = "monhoc.txt"
        print(f"Khởi tạo Hệ thống Quản lý Môn học. Dữ liệu sẽ được lưu vào '{self.ten_file}'")

    # a. Thêm một môn học
    def themMonHoc(self):
        print("\n--- Thêm Môn Học Mới ---")
        ma_mon = input("Nhập mã môn học: ")
        
        # Kiểm tra trùng lặp mã
        for mh in self.danh_sach_mon_hoc:
            if mh.ma_mon == ma_mon:
                print("Lỗi: Mã môn học này đã tồn tại.")
                return

        ten_mon = input("Nhập tên môn học: ")
        so_tin_chi = int(input("Nhập số tín chỉ: "))
        
        mon_hoc_moi = MonHoc(ma_mon, ten_mon, so_tin_chi)
        self.danh_sach_mon_hoc.append(mon_hoc_moi)
        print("Đã thêm môn học thành công!")

    # b. Xóa một môn học theo mã X
    def xoaMonHoc(self):
        print("\n--- Xóa Môn Học ---")
        ma_x = input("Nhập mã môn học cần xóa: ")
        
        mon_hoc_can_xoa = None
        for mh in self.danh_sach_mon_hoc:
            if mh.ma_mon == ma_x:
                mon_hoc_can_xoa = mh
                break
        
        if mon_hoc_can_xoa:
            self.danh_sach_mon_hoc.remove(mon_hoc_can_xoa)
            print(f"Đã xóa môn học có mã {ma_x} thành công.")
        else:
            print(f"Không tìm thấy môn học nào có mã {ma_x}.")

    # c. Hiển thị thông tin môn học
    def hienThiThongTin(self):
        print("\n--- DANH SÁCH MÔN HỌC HIỆN TẠI ---")
        if not self.danh_sach_mon_hoc:
            print("Chưa có môn học nào trong danh sách.")
            return
            
        print("-" * 52)
        print(f"| {'Mã Môn':<10} | {'Tên Môn Học':<25} | {'Tín Chỉ':<8} |")
        print("-" * 52)
        for mh in self.danh_sach_mon_hoc:
            print(mh) # Tự động gọi hàm __str__ của lớp MonHoc
        print("-" * 52)

    # d. Tìm kiếm môn học
    def timKiemMonHoc(self):
        print("\n--- Tìm Kiếm Môn Học ---")
        tu_khoa = input("Nhập tên, mã môn, hoặc số tín chỉ để tìm: ").lower()
        
        ket_qua = []
        for mh in self.danh_sach_mon_hoc:
            if (tu_khoa in mh.ten_mon.lower() or 
                tu_khoa == mh.ma_mon.lower() or
                tu_khoa == str(mh.so_tin_chi)):
                ket_qua.append(mh)
        
        if ket_qua:
            print(f"Tìm thấy {len(ket_qua)} kết quả:")
            print("-" * 52)
            print(f"| {'Mã Môn':<10} | {'Tên Môn Học':<25} | {'Tín Chỉ':<8} |")
            print("-" * 52)
            for mh in ket_qua:
                print(mh)
            print("-" * 52)
        else:
            print("Không tìm thấy kết quả nào phù hợp.")

    # e. Ghi thông tin vào tệp monhoc.txt
    def ghiFile(self):
        print(f"\n--- Ghi dữ liệu ra file {self.ten_file} ---")
        try:
            with open(self.ten_file, 'w', encoding='utf-8') as f:
                # Ghi từng môn học, mỗi thuộc tính cách nhau bằng dấu phẩy
                for mh in self.danh_sach_mon_hoc:
                    dong_du_lieu = f"{mh.ma_mon},{mh.ten_mon},{mh.so_tin_chi}\n"
                    f.write(dong_du_lieu)
            print("Ghi file thành công!")
        except Exception as e:
            print(f"Lỗi khi ghi file: {e}")

    # f. Đọc dữ liệu từ tệp monhoc.txt
    def docFile(self):
        print(f"\n--- Đọc dữ liệu từ file {self.ten_file} ---")
        
        # Kiểm tra file có tồn tại không
        if not os.path.exists(self.ten_file):
            print("File không tồn tại. Bỏ qua việc đọc file.")
            return

        try:
            with open(self.ten_file, 'r', encoding='utf-8') as f:
                self.danh_sach_mon_hoc = [] # Xóa danh sách cũ
                for line in f:
                    # Bỏ qua các dòng trống
                    if line.strip():
                        # Tách dữ liệu bằng dấu phẩy
                        parts = line.strip().split(',')
                        if len(parts) == 3:
                            ma_mon = parts[0]
                            ten_mon = parts[1]
                            so_tin_chi = int(parts[2])
                            
                            mon_hoc_moi = MonHoc(ma_mon, ten_mon, so_tin_chi)
                            self.danh_sach_mon_hoc.append(mon_hoc_moi)
            print(f"Đọc file thành công. Đã tải {len(self.danh_sach_mon_hoc)} môn học.")
        except Exception as e:
            print(f"Lỗi khi đọc file: {e}")


# --- Ví dụ sử dụng Lớp Quản lý Môn Học ---
print("\n" + "="*30)
print("--- CHƯƠNG TRÌNH QUẢN LÝ MÔN HỌC ---")
qlmh = QuanLyMonHoc()

# f. Thử đọc file lúc đầu (nếu có)
qlmh.docFile()
qlmh.hienThiThongTin()

# a. Thêm mới
qlmh.themMonHoc() # Thêm môn Lập trình Python
qlmh.themMonHoc() # Thêm môn Cơ sở dữ liệu

# c. Hiển thị
qlmh.hienThiThongTin()

# e. Ghi file
qlmh.ghiFile()

# b. Xóa
qlmh.xoaMonHoc()
qlmh.hienThiThongTin()

# d. Tìm kiếm
qlmh.timKiemMonHoc()