import math

class HinhTron:
    def __init__(self, ban_kinh):
        self.ban_kinh = ban_kinh

    def tinhChuVi(self):
        return 2 * math.pi * self.ban_kinh

    def tinhDienTich(self):
        return math.pi * (self.ban_kinh ** 2)

    def hienThiThongTin(self):
        print(f"--- Thông tin Hình Tròn ---")
        print(f"Bán kính: {self.ban_kinh}")
        print(f"Chu vi: {self.tinhChuVi():.2f}")
        print(f"Diện tích: {self.tinhDienTich():.2f}")
        # (Việc "vẽ đường tròn" cần thư viện đồ họa như Turtle hoặc Pygame)
