def generate_n_even_numbers(n):
    """
    Sinh ra n số chẵn đầu tiên, bắt đầu từ 0.
    """
    count = 0
    num = 0
    while count < n:
        yield num
        num += 2 # Số chẵn tiếp theo
        count += 1

# Ví dụ sử dụng:
n_value = 7
print(f"1a) {n_value} số chẵn đầu tiên: ", end="")
for num in generate_n_even_numbers(n_value):
    print(num, end=", ")
print("\n")