# Câu 3: Viết hàm sinh ra tất cả các chuỗi số nhị phân có chiều dài n.

from itertools import product

n = int(input("Nhập chiều dài n: "))
print(f"Tất cả chuỗi nhị phân có chiều dài {n}:")
for p in product('01', repeat=n):
    print(''.join(p))
