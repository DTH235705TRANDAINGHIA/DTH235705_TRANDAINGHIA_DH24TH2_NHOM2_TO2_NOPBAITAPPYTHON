def in_cuu_chuong(n):
    if not (1 < n < 9):
        return "Yêu cầu 1 < n < 9"
    for i in range(1, 11):
        print(f"{n} * {i} = {n*i}")
