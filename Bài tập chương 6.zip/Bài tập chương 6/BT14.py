class SinhVien:
    def __init__(self, ma_sv, ho_ten, lop, que_quan):
        self.ma_sv = ma_sv
        self.ho_ten = ho_ten
        self.lop = lop
        self.que_quan = que_quan

    def __str__(self):
        # Dùng để ghi vào file
        return f"{self.ma_sv};{self.ho_ten};{self.lop};{self.que_quan}"
    
    def hien_thi(self):
        print(f" - {self.ma_sv} | {self.ho_ten:<20} | {self.lop:<10} | {self.que_quan}")

class QuanLySinhVien:
    def __init__(self):
        self.danh_sach_sv = [] # List các đối tượng SinhVien

    # a. Nhập danh sách sinh viên
    def nhap_danh_sach(self):
        print("--- (a) Nhập danh sách sinh viên ---")
        while True:
            ma_sv = input("Nhập mã SV (nhấn Enter để dừng): ")
            if not ma_sv:
                break
            ho_ten = input("  Nhập họ tên: ")
            lop = input("  Nhập lớp: ")
            que_quan = input("  Nhập quê quán: ")
            sv = SinhVien(ma_sv, ho_ten, lop, que_quan)
            self.danh_sach_sv.append(sv)
            print("Đã thêm sinh viên.")

    # b. Lưu thông tin vào tệp svchung.txt
    def luu_file(self, ten_file="svchung.txt"):
        print(f"--- (b) Lưu vào tệp {ten_file} ---")
        try:
            with open(ten_file, 'w', encoding='utf-8') as f:
                for sv in self.danh_sach_sv:
                    f.write(str(sv) + "\n") # Gọi hàm __str__
            print("Lưu file thành công.")
        except Exception as e:
            print(f"Lỗi khi lưu file: {e}")

    # c. Hiển thị sinh viên của lớp X
    def hien_thi_theo_lop(self):
        lop_can_tim = input("--- (c) Nhập lớp cần hiển thị: ")
        print(f"--- Danh sách sinh viên lớp {lop_can_tim} ---")
        tim_thay = False
        for sv in self.danh_sach_sv:
            if sv.lop.lower() == lop_can_tim.lower():
                sv.hien_thi()
                tim_thay = True
        if not tim_thay:
            print("Không tìm thấy sinh viên nào của lớp này.")

    # d. Hiển thị sinh viên có tên X
    def hien_thi_theo_ten(self):
        ten_can_tim = input("--- (d) Nhập tên SV cần tìm: ")
        print(f"--- Danh sách sinh viên có tên '{ten_can_tim}' ---")
        tim_thay = False
        for sv in self.danh_sach_sv:
            # Tìm kiếm đơn giản (tên có trong họ tên)
            if ten_can_tim.lower() in sv.ho_ten.lower():
                sv.hien_thi()
                tim_thay = True
        if not tim_thay:
            print("Không tìm thấy sinh viên nào có tên này.")

    # e. Đọc tệp và ghi sang các tệp theo lớp
    def doc_va_chia_file(self, file_chung="svchung.txt"):
        print(f"--- (e) Đọc {file_chung} và chia tệp theo lớp ---")
        
        # Đọc lại dữ liệu từ file (hoặc có thể dùng list hiện tại)
        danh_sach_doc = []
        try:
            with open(file_chung, 'r', encoding='utf-8') as f:
                for dong in f:
                    parts = dong.strip().split(';')
                    if len(parts) == 4:
                        sv = SinhVien(parts[0], parts[1], parts[2], parts[3])
                        danh_sach_doc.append(sv)
        except FileNotFoundError:
            print(f"Không tìm thấy {file_chung} để đọc.")
            return
        
        # Tìm các lớp duy nhất
        cac_lop = set(sv.lop for sv in danh_sach_doc)
        print(f"Tìm thấy các lớp: {cac_lop}")

        # Ghi ra các tệp riêng
        for lop in cac_lop:
            ten_file_lop = f"{lop}.txt"
            try:
                with open(ten_file_lop, 'w', encoding='utf-8') as f_lop:
                    for sv in danh_sach_doc:
                        if sv.lop == lop:
                            f_lop.write(str(sv) + "\n")
                print(f"Đã ghi danh sách lớp {lop} vào tệp {ten_file_lop}")
            except Exception as e:
                print(f"Lỗi khi ghi tệp cho lớp {lop}: {e}")

# Ví dụ sử dụng:
def main_bai_14():
    qlsv = QuanLySinhVien()
    qlsv.nhap_danh_sach() # (a)
    qlsv.luu_file() # (b)
    qlsv.hien_thi_theo_lop() # (c)
    qlsv.hien_thi_theo_ten() # (d)
    qlsv.doc_va_chia_file() # (e)

# main_bai_14()