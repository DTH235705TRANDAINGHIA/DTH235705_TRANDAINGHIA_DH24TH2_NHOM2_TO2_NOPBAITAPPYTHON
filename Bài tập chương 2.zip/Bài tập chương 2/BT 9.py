def cac_tong(n):
    S = n*(n+1)//2
    S1 = n*n   
    S2 = n*(n+1)  
    S3 = n*(n+1)*(2*n+1)//6
    S4 = sum(1/i for i in range(1, n+1))
    return {"S":S, "S1":S1, "S2":S2, "S3":S3, "S4":S4}


