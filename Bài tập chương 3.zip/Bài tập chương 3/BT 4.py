# Câu 4: Viết chương trình tạo một chuỗi tùy ý có độ dài n ký tự gồm chữ + số.
# Sau đó viết hàm đảo ngược chuỗi và đếm chữ cái, chữ số.

import random
import string

n = int(input("Nhập độ dài chuỗi: "))
chars = string.ascii_letters + string.digits
s = ''.join(random.choice(chars) for _ in range(n))
print("Chuỗi ngẫu nhiên:", s)

# a) Đảo ngược chuỗi
print("Chuỗi đảo ngược:", s[::-1])

# b) Đếm chữ cái và chữ số
chu_cai = sum(c.isalpha() for c in s)
chu_so = sum(c.isdigit() for c in s)
print("Số chữ cái:", chu_cai)
print("Số chữ số:", chu_so)
