def chuan_hoa_ten(ten):
    ten = ten.strip()
    ten = " ".join(ten.split())
    ten = ten.title()
    return ten

s = input("Nhập họ tên: ")
print("Chuỗi họ tên sau khi chuẩn hóa:", chuan_hoa_ten(s))
