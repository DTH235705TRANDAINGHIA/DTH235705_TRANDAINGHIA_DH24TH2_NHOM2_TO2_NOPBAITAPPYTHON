# --- CÁC HÀM NHẬP LIỆU CÓ KIỂM TRA TÍNH HỢP LỆ ---

def nhap_so_bao_danh():
    """
    Nhập và kiểm tra số báo danh.
    Yêu cầu: 5 ký tự và phải là chuỗi số.
    """
    while True:
        sbd = input("  - Nhập số báo danh (đúng 5 chữ số): ")
        if len(sbd) == 5 and sbd.isdigit():
            return sbd
        else:
            print("  Lỗi: Số báo danh phải là 5 chữ số. Vui lòng nhập lại.")

def nhap_ho_ten():
    """
    Nhập và kiểm tra họ tên.
    Yêu cầu: Không rỗng và không quá 25 ký tự.
    """
    while True:
        ho_ten = input("  - Nhập họ và tên (tối đa 25 ký tự): ")
        if 0 < len(ho_ten) <= 25:
            return ho_ten
        else:
            print("  Lỗi: Họ tên không được rỗng và phải <= 25 ký tự. Vui lòng nhập lại.")

def nhap_diem(ten_mon):
    """
    Nhập và kiểm tra điểm số.
    Yêu cầu: Số thực trong khoảng [0, 10].
    """
    while True:
        try:
            diem = float(input(f"  - Nhập điểm {ten_mon} (từ 0 đến 10): "))
            if 0 <= diem <= 10:
                return diem
            else:
                print("  Lỗi: Điểm phải là một số trong khoảng [0, 10]. Vui lòng nhập lại.")
        except ValueError:
            print("  Lỗi: Vui lòng nhập một con số hợp lệ.")

# --- CÁC HÀM CHỨC NĂNG CHÍNH (THEO YÊU CẦU ĐỀ BÀI) ---

def nhap_danh_sach_thi_sinh():
    """
    e.1. Nhập danh sách thí sinh từ bàn phím.
    Hàm này sẽ trả về một list chứa các dictionary, mỗi dictionary là một thí sinh.
    """
    print("--- CHỨC NĂNG: NHẬP DANH SÁCH THÍ SINH ---")
    danh_sach = []
    
    # Hỏi người dùng muốn nhập bao nhiêu thí sinh
    while True:
        try:
            so_luong = int(input("Bạn muốn nhập thông tin cho bao nhiêu thí sinh? "))
            if so_luong > 0:
                break
            else:
                print("Lỗi: Số lượng phải lớn hơn 0.")
        except ValueError:
            print("Lỗi: Vui lòng nhập một số nguyên.")

    # Vòng lặp để nhập thông tin từng thí sinh
    for i in range(so_luong):
        print(f"\n--- Nhập thông tin cho thí sinh thứ {i + 1} ---")
        
        # Sử dụng các hàm nhập liệu có kiểm tra
        sbd = nhap_so_bao_danh()
        ho_ten = nhap_ho_ten()
        diem_toan = nhap_diem("Toán")
        diem_tieng_viet = nhap_diem("Tiếng Việt")
        
        # Tạo dictionary cho thí sinh
        thi_sinh = {
            "so_bao_danh": sbd,
            "ho_ten": ho_ten,
            "diem_toan": diem_toan,
            "diem_tieng_viet": diem_tieng_viet
        }
        
        # Thêm vào danh sách
        danh_sach.append(thi_sinh)
        
    print("\nĐã nhập xong danh sách thí sinh!")
    return danh_sach

def hien_thi_danh_sach(danh_sach, tieu_de):
    """
    e.2. Hàm chung để hiển thị danh sách thí sinh ra màn hình.
    Hàm này được tái sử dụng cho các yêu cầu hiển thị khác.
    """
    print(f"\n--- {tieu_de.upper()} ---")
    
    if not danh_sach:
        print("Không có thí sinh nào trong danh sách này.")
        return

    # In tiêu đề của bảng
    print(f"{'SBD':<6} | {'Họ và Tên':<26} | {'Điểm Toán':<10} | {'Điểm Tiếng Việt':<15} | {'Tổng Điểm':<10}")
    print("-" * 70)
    
    # In thông tin từng thí sinh
    for ts in danh_sach:
        tong_diem = ts['diem_toan'] + ts['diem_tieng_viet']
        
        # Định dạng f-string:
        # :<6   -> Căn trái, chiều rộng 6 ký tự
        # :<26  -> Căn trái, chiều rộng 26 ký tự
        # :<10.2f -> Căn trái, rộng 10, 2 chữ số thập phân
        
        print(f"{ts['so_bao_danh']:<6} | {ts['ho_ten']:<26} | {ts['diem_toan']:<10.2f} | {ts['diem_tieng_viet']:<15.2f} | {tong_diem:<10.2f}")

def hien_thi_tong_diem_lon_hon_10(danh_sach):
    """
    e.3. Hiển thị danh sách thí sinh có tổng điểm > 10.
    """
    # Tạo một danh sách mới chỉ chứa các thí sinh thỏa mãn điều kiện
    ds_loc = []
    for ts in danh_sach:
        tong_diem = ts['diem_toan'] + ts['diem_tieng_viet']
        if tong_diem > 10:
            ds_loc.append(ts)
            
    # Cách viết ngắn gọn hơn dùng list comprehension:
    # ds_loc = [ts for ts in danh_sach if (ts['diem_toan'] + ts['diem_tieng_viet']) > 10]
            
    # Gọi hàm hiển thị chung
    hien_thi_danh_sach(ds_loc, "DANH SÁCH THÍ SINH CÓ TỔNG ĐIỂM > 10")

def hien_thi_thi_sinh_bi_diem_liet(danh_sach):
    """
    e.4. Hiển thị danh sách thí sinh có điểm liệt (ít nhất 1 điểm 0).
    """
    # Tạo danh sách mới chứa các thí sinh bị điểm liệt
    ds_loc = []
    for ts in danh_sach:
        if ts['diem_toan'] == 0 or ts['diem_tieng_viet'] == 0:
            ds_loc.append(ts)
            
    # Cách viết ngắn gọn hơn dùng list comprehension:
    # ds_loc = [ts for ts in danh_sach if ts['diem_toan'] == 0 or ts['diem_tieng_viet'] == 0]
            
    # Gọi hàm hiển thị chung
    hien_thi_danh_sach(ds_loc, "DANH SÁCH THÍ SINH BỊ ĐIỂM LIỆT (CÓ ĐIỂM 0)")

# --- HÀM CHẠY CHÍNH ---
def main():
    """
    Hàm chính điều phối toàn bộ chương trình.
    """
    # 1. Nhập danh sách
    ds_thi_sinh = nhap_danh_sach_thi_sinh()
    
    # Nếu danh sách rỗng (người dùng không nhập ai) thì không làm gì thêm
    if not ds_thi_sinh:
        print("Danh sách rỗng. Kết thúc chương trình.")
        return

    # 2. Hiển thị toàn bộ danh sách
    hien_thi_danh_sach(ds_thi_sinh, "DANH SÁCH TOÀN BỘ THÍ SINH")
    
    # 3. Hiển thị danh sách có tổng điểm > 10
    hien_thi_tong_diem_lon_hon_10(ds_thi_sinh)
    
    # 4. Hiển thị danh sách bị điểm liệt
    hien_thi_thi_sinh_bi_diem_liet(ds_thi_sinh)

# --- KHỞI CHẠY CHƯƠNG TRÌNH ---
if __name__ == "__main__":
    main()