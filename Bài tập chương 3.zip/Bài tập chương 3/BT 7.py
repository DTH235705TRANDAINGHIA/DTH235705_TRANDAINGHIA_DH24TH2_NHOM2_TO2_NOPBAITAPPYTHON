# Câu 7: Cho chuỗi S, tìm số ký tự ít nhất cần thêm để S trở thành chuỗi đối xứng.

def can_them_de_doi_xung(s):
    for i in range(len(s)):
        if s[i:] == s[i:][::-1]:
            return i
    return len(s) - 1

s = input("Nhập chuỗi: ")
print("Số ký tự cần thêm để đối xứng:", can_them_de_doi_xung(s))
