from collections import defaultdict

def merge_dictionaries(d1, d2):
    """
    Kết hợp 2 từ điển: cộng giá trị nếu khóa trùng, giữ nguyên khóa không trùng.
    """
    merged = defaultdict(int)
    
    # Cộng giá trị từ từ điển d1
    for key, value in d1.items():
        merged[key] += value
        
    # Cộng giá trị từ từ điển d2
    for key, value in d2.items():
        merged[key] += value
        
    # Chuyển kết quả trở lại thành dictionary thông thường
    return dict(merged)

# Ví dụ minh họa:
d1 = {'a': 100, 'b': 200}
d2 = {'a': 300, 'y': 200}

print(f"d1: {d1}")
print(f"d2: {d2}")
print(f"Kết quả merge: {merge_dictionaries(d1, d2)}")
# Kết quả: {'a': 400, 'b': 200, 'y': 200} (Ví dụ trong đề là {'a': 300, 'b': 200, 'y': 200} - có thể đề bài có lỗi hoặc yêu cầu khác, 
# nhưng theo quy tắc merge thông thường và ví dụ 12 thì đáp án là cộng giá trị)