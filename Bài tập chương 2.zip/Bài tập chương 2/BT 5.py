def doc_hai_chu_so(n):
    if not (0 <= n <= 99):
        return "Chỉ cho phép 0–99"
    chu_so = ["không","một","hai","ba","bốn","năm","sáu","bảy","tám","chín"]
    if n < 10:
        return chu_so[n]
    hang_chuc = n // 10
    hang_dv = n % 10
    if hang_chuc == 1:
        if hang_dv == 0:
            return "mười"
        if hang_dv == 5:
            return "mười lăm"
        return "mười " + chu_so[hang_dv]
    else:
        chuc_text = chu_so[hang_chuc] + " mươi"
        if hang_dv == 0:
            return chuc_text
        if hang_dv == 1:
            return chuc_text + " mốt"
        if hang_dv == 5:
            return chuc_text + " lăm"
        return chuc_text + " " + chu_so[hang_dv]

