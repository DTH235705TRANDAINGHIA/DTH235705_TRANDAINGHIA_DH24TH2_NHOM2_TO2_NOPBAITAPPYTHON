def doc_n_dong_dau_tien(ten_file, n):
    """
    Đọc n dòng đầu tiên của một tệp văn bản.
    """
    try:
        with open(ten_file, 'r', encoding='utf-8') as f:
            print(f"--- {n} dòng đầu tiên của tệp {ten_file} ---")
            for i in range(n):
                dong = f.readline()
                if not dong: # Nếu hết file
                    break
                print(dong.strip()) # strip() để bỏ ký tự \n
    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy tệp {ten_file}")
    except Exception as e:
        print(f"Đã xảy ra lỗi: {e}")
