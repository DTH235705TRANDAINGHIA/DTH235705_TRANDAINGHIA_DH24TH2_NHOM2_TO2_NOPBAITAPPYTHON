chuoi = input("Nhập chuỗi: ")  # ví dụ: 5;7;8;-2;8;11;13;9;10
so_list = [int(x) for x in chuoi.replace(';', ':').split(':')]

print("Các số là:", *so_list)

chan = [x for x in so_list if x % 2 == 0]
am = [x for x in so_list if x < 0]

def la_nt(n):
    if n < 2: return False
    for i in range(2, int(n**0.5)+1):
        if n % i == 0: return False
    return True

nt = [x for x in so_list if la_nt(x)]

print("Số chẵn:", len(chan))
print("Số âm:", len(am))
print("Số nguyên tố:", len(nt))
print("Giá trị trung bình:", sum(so_list)/len(so_list))
