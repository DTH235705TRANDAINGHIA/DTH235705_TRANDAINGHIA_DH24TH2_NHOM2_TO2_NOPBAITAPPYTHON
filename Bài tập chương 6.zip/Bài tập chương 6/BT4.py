def doc_n_dong_cuoi_tep(ten_file, n):
    """
    Đọc n dòng cuối cùng của tệp.
    Cách đơn giản là đọc tất cả các dòng và lấy n dòng cuối.
    """
    try:
        with open(ten_file, 'r', encoding='utf-8') as f:
            tat_ca_dong = f.readlines()
            
            print(f"--- {n} dòng cuối cùng của tệp {ten_file} ---")
            # Sử dụng slicing để lấy n phần tử cuối
            for dong in tat_ca_dong[-n:]:
                print(dong.strip())
    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy tệp {ten_file}")
    except Exception as e:
        print(f"Đã xảy ra lỗi: {e}")

