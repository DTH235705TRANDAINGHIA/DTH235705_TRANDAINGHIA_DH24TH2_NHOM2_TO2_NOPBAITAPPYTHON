def factorial(n):
    """
    Tính giai thừa của n (n!).
    """
    if n < 0:
        return "Lỗi: Giai thừa không xác định cho số âm."
    if n == 0 or n == 1:
        return 1
    
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

# Ví dụ sử dụng:
n_value = 5
print(f"3) Giai thừa của {n_value} ({n_value}!): {factorial(n_value)}") # Kết quả: 120
print("\n")