def noi_chuoi_vao_tep(ten_file, chuoi_can_them):
    """
    Mở tệp ở chế độ 'a' (append) và ghi chuỗi vào cuối.
    """
    try:
        with open(ten_file, 'a', encoding='utf-8') as f:
            f.write(chuoi_can_them + "\n")
        print(f"Đã thêm chuỗi vào cuối tệp {ten_file}.")
    except Exception as e:
        print(f"Đã xảy ra lỗi: {e}")
