def calculate_polynomial():
    """
    Nhập hệ số và giá trị x, sau đó tính giá trị đa thức Pn.
    """
    print("--- TÍNH GIÁ TRỊ ĐA THỨC Pn ---")
    try:
        # 1. Nhập bậc n của đa thức
        n = int(input("Nhập bậc cao nhất của đa thức (n): "))
        if n < 0:
            print("Bậc phải là số nguyên không âm.")
            return

        # 2. Nhập các hệ số (a0, a1, ..., an)
        coefficients = []
        print(f"Nhập {n + 1} hệ số:")
        for i in range(n + 1):
            a_i = float(input(f"Nhập hệ số a{i}: "))
            coefficients.append(a_i)

        # 3. Nhập giá trị x
        x = float(input("Nhập giá trị x để tính Pn(x): "))

        # 4. Tính giá trị đa thức Pn(x)
        # Sử dụng phương pháp Horner (hiệu quả hơn) hoặc tính toán trực tiếp
        
        # Phương pháp trực tiếp: Pn(x) = sum(a_i * x**i)
        Pn_x = 0
        for i in range(n + 1):
            # coefficients[i] là a_i (hệ số của x^i)
            # i là bậc của x
            Pn_x += coefficients[i] * (x ** i)

        # 5. Hiển thị kết quả
        print("\n--- KẾT QUẢ ---")
        polynomial_str = " + ".join([f"({coefficients[i]})x^{i}" if i > 0 else f"({coefficients[i]})" for i in range(n + 1)])
        print(f"Đa thức: Pn(x) = {polynomial_str}")
        print(f"Với x = {x}, giá trị của đa thức là: Pn({x}) = {Pn_x}")

    except ValueError:
        print("Lỗi: Đầu vào không hợp lệ. Vui lòng nhập số.")
    except Exception as e:
        print(f"Đã xảy ra lỗi: {e}")

# Chạy chương trình đa thức (bỏ comment để chạy thử)
# calculate_polynomial()