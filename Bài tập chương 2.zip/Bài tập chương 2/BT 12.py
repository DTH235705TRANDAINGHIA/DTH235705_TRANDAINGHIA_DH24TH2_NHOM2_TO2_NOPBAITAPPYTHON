def dec_to_bin(n):
    if n == 0:
        return "0"
    bits = []
    nn = n
    while nn > 0:
        bits.append(str(nn % 2))
        nn //= 2
    return ''.join(reversed(bits))

print(dec_to_bin(13))  # "1101"
# hoặc dùng:
print(bin(13)[2:])
