import math

def S_x_n(x, n):
    s = 0.0
    fact = 1
    for k in range(1, n+1):
        fact *= k
        s += x**k / fact
    return s

print(S_x_n(2,5))
