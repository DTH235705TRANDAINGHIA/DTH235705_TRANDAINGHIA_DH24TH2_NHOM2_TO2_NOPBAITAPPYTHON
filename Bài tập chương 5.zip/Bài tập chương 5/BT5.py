import math

class Diem:
    # a. Hàm khởi tạo
    def __init__(self, x, y, mau_sac):
        self.x = x
        self.y = y
        self.mau_sac = mau_sac

    # b. Hiển thị thông tin
    def hienThiThongTin(self):
        print(f"Điểm(x={self.x}, y={self.y}), Màu: {self.mau_sac}")

    # c. Tịnh tiến theo trục hoành (Ox)
    def tinhTien_x(self, dx):
        self.x += dx
        print(f"Tịnh tiến Ox({dx}). Tọa độ mới: ({self.x}, {self.y})")

    # d. Tịnh tiến theo cả 2 trục
    def tinhTien_xy(self, dx, dy):
        self.x += dx
        self.y += dy
        print(f"Tịnh tiến Oxy({dx}, {dy}). Tọa độ mới: ({self.x}, {self.y})")

    # e. Tính khoảng cách đến gốc tọa độ O(0,0)
    def khoangCachGoc(self):
        khoang_cach = math.sqrt(self.x**2 + self.y**2)
        return khoang_cach

# Ví dụ sử dụng:
print("\n--- Lớp Điểm ---")
d1 = Diem(3, 4, "Đỏ")
d1.hienThiThongTin()

d1.tinhTien_x(5) # Tịnh tiến Ox
d1.tinhTien_xy(-2, 10) # Tịnh tiến cả 2 trục

kc = d1.khoangCachGoc()
print(f"Khoảng cách từ điểm hiện tại đến gốc O: {kc:.2f}")