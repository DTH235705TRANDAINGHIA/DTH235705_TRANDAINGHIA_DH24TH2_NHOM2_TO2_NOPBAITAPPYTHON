def may_tinh(a, b, ch):
    if ch == '+':
        return a + b
    elif ch == '-':
        return a - b
    elif ch == '*':
        return a * b
    elif ch == '/':
        if b == 0:
            return "Lỗi: chia cho 0"
        return a / b
    else:
        return f"Ký tự '{ch}' không phải là một toán tử."

