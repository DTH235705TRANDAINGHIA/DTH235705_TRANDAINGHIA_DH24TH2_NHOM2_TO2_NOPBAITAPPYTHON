from tkinter import *
from tkinter import messagebox
import math

def giai_pt():
    try:
        a = float(txt_a.get())
        b = float(txt_b.get())
        c = float(txt_c.get())
        if a == 0:
            # Giảm về phương trình bậc 1
            if b == 0:
                if c == 0:
                    kq.set("Vô số nghiệm")
                else:
                    kq.set("Vô nghiệm")
            else:
                x = -c / b
                kq.set(f"PT bậc 1: x = {x:.2f}")
        else:
            delta = b**2 - 4*a*c
            if delta < 0:
                kq.set("Vô nghiệm")
            elif delta == 0:
                x = -b / (2*a)
                kq.set(f"x1 = x2 = {x:.2f}")
            else:
                x1 = (-b + math.sqrt(delta)) / (2*a)
                x2 = (-b - math.sqrt(delta)) / (2*a)
                kq.set(f"x1 = {x1:.2f}, x2 = {x2:.2f}")
    except ValueError:
        messagebox.showerror("Lỗi", "Vui lòng nhập số hợp lệ!")

def tiep():
    txt_a.delete(0, END)
    txt_b.delete(0, END)
    txt_c.delete(0, END)
    kq.set("")

def thoat():
    root.destroy()

root = Tk()
root.title("PTB2")

Label(root, text="Phương Trình Bậc 2", font=("Arial", 14, "bold")).grid(row=0, column=0, columnspan=2, pady=10)

Label(root, text="Hệ số a:").grid(row=1, column=0, sticky=W)
txt_a = Entry(root)
txt_a.grid(row=1, column=1)

Label(root, text="Hệ số b:").grid(row=2, column=0, sticky=W)
txt_b = Entry(root)
txt_b.grid(row=2, column=1)

Label(root, text="Hệ số c:").grid(row=3, column=0, sticky=W)
txt_c = Entry(root)
txt_c.grid(row=3, column=1)

frame_btn = Frame(root)
frame_btn.grid(row=4, column=0, columnspan=2, pady=10)

Button(frame_btn, text="Giải", command=giai_pt, width=10).pack(side=LEFT, padx=5)
Button(frame_btn, text="Tiếp", command=tiep, width=10).pack(side=LEFT, padx=5)
Button(frame_btn, text="Thoát", command=thoat, width=10).pack(side=LEFT, padx=5)

kq = StringVar()
Label(root, text="Kết quả:").grid(row=5, column=0, sticky=W)
Entry(root, textvariable=kq, state='readonly', width=40).grid(row=5, column=1)

root.mainloop()