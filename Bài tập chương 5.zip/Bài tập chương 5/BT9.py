class Student:
    # a. (Constructor được ngầm định)
    def __init__(self):
        self.ma_sinh_vien = ""
        self.diem_trung_binh = 0.0
        self.tuoi = 0
        self.lop = ""

    # b. Phương thức inputInfo
    def inputInfo(self):
        print("\n--- Nhập thông tin Student ---")
        self.ma_sinh_vien = input("Nhập mã sinh viên: ")
        self.diem_trung_binh = float(input("Nhập điểm trung bình: "))
        self.tuoi = int(input("Nhập tuổi: "))
        self.lop = input("Nhập lớp: ")

    # c. Phương thức showInfo
    def showInfo(self):
        print("\n--- Thông tin Student ---")
        print(f"Mã SV: {self.ma_sinh_vien}, Lớp: {self.lop}")
        print(f"Tuổi: {self.tuoi}")
        print(f"Điểm TB: {self.diem_trung_binh}")

    # d. Phương thức xét học bổng
    def kiemTraHocBong(self):
        print(f"--- Xét học bổng cho SV {self.ma_sinh_vien} ---")
        if self.diem_trung_binh >= 8.0:
            print(f"Kết quả: **ĐƯỢC HỌC BỔNG** (Điểm TB: {self.diem_trung_binh})")
            return True
        else:
            print(f"Kết quả: **KHÔNG ĐƯỢC HỌC BỔNG** (Điểm TB: {self.diem_trung_binh})")
            return False

# Ví dụ sử dụng:
print("\n--- Lớp Student ---")
sv1 = Student()
sv1.inputInfo()
sv1.showInfo()
sv1.kiemTraHocBong()

sv2 = Student()
sv2.ma_sinh_vien = "SV002"
sv2.diem_trung_binh = 7.9
sv2.showInfo()
sv2.kiemTraHocBong()