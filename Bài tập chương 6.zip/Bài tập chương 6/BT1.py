def doc_va_hien_thi_file(ten_file):
    """
    Đọc toàn bộ nội dung của một tệp văn bản và hiển thị lên màn hình.
    """
    try:
        with open(ten_file, 'r', encoding='utf-8') as f:
            noi_dung = f.read()
            print(f"--- Nội dung của tệp {ten_file} ---")
            print(noi_dung)
    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy tệp {ten_file}")
    except Exception as e:
        print(f"Đã xảy ra lỗi: {e}")
