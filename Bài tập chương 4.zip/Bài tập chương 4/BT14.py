def manage_sales():
    """
    Quản lý và phân tích doanh số bán hàng của 10 cửa hàng Yody Fashion.
    """
    print("--- QUẢN LÝ DOANH SỐ BÁN HÀNG YODY FASHION ---")
    
    # Khởi tạo danh sách cửa hàng
    stores = []
    NUM_STORES = 10

    # a. Nhập doanh số bán hàng từ người dùng
    print(f"\n1. Nhập doanh số bán hàng cho {NUM_STORES} cửa hàng:")
    for i in range(1, NUM_STORES + 1):
        while True:
            try:
                sales = float(input(f"Nhập doanh số cửa hàng {i} (triệu VNĐ): "))
                if sales >= 0:
                    stores.append({'id': i, 'sales': sales})
                    break
                else:
                    print("Doanh số phải là số không âm.")
            except ValueError:
                print("Lỗi: Vui lòng nhập một số hợp lệ.")

    # Hiển thị danh sách ban đầu
    print("\n--- Danh sách doanh số đã nhập ---")
    for store in stores:
        print(f"Cửa hàng {store['id']}: {store['sales']} triệu VNĐ")

    # b. Sắp xếp doanh số bán hàng từ bé đến lớn
    # Dùng hàm sorted() để tạo danh sách mới đã sắp xếp
    stores_sorted = sorted(stores, key=lambda x: x['sales'])

    print("\n2. Danh sách doanh số đã sắp xếp (bé đến lớn):")
    for store in stores_sorted:
        print(f"Cửa hàng {store['id']}: {store['sales']} triệu VNĐ")

    # c. Tính doanh số trung bình trên 10 cửa hàng
    total_sales = sum(store['sales'] for store in stores)
    average_sales = total_sales / NUM_STORES

    print(f"\n3. Tổng doanh số của 10 cửa hàng: {total_sales:.2f} triệu VNĐ")
    print(f"4. Doanh số bán hàng **trung bình** trên 10 cửa hàng: **{average_sales:.2f} triệu VNĐ**")

    # d. Hiển thị danh sách cửa hàng có doanh số lớn hơn
    # hoặc bằng doanh số trung bình (thường là lớn hơn/cao hơn trung bình)
    high_performing_stores = [store for store in stores if store['sales'] > average_sales]

    print("\n5. Danh sách cửa hàng có doanh số **CAO HƠN** trung bình:")
    if high_performing_stores:
        for store in high_performing_stores:
            print(f"Cửa hàng {store['id']}: {store['sales']:.2f} triệu VNĐ (Cao hơn TB: {average_sales:.2f})")
    else:
        print("Không có cửa hàng nào có doanh số cao hơn trung bình.")
        
    # Phần bổ sung: Tìm cửa hàng có doanh số cao nhất
    best_store = stores_sorted[-1] # Lấy phần tử cuối cùng của danh sách đã sắp xếp

    print("\n--- KẾ HOẠCH KINH DOANH VÀ TẶNG THƯỞNG ---")
    print(f"Cửa hàng có doanh số cao nhất là **Cửa hàng {best_store['id']}**")
    print(f"Với doanh số: **{best_store['sales']:.2f} triệu VNĐ**")

# Chạy chương trình quản lý doanh số (bỏ comment để chạy thử)
# manage_sales()