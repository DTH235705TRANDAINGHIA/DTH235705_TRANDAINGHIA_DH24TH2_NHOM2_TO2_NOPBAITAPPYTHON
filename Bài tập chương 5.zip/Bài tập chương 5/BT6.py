class ToanHoc:
    def __init__(self, *nso):
        # *nso cho phép nhận nhiều số làm tham số (ví dụ: ToanHoc(1, 2, 3))
        # và chúng được gói lại thành một tuple.
        self.danh_sach_so = list(nso)
        print(f"Khởi tạo lớp ToanHoc với {len(self.danh_sach_so)} số.")

    # a. Tính tổng n số
    def tinhTong(self):
        if not self.danh_sach_so:
            return 0
        return sum(self.danh_sach_so)

    # b. Tính trung bình cộng
    def tinhTrungBinh(self):
        if not self.danh_sach_so:
            return 0
        return sum(self.danh_sach_so) / len(self.danh_sach_so)

    # c. Tìm số lớn nhất
    def timMax(self):
        if not self.danh_sach_so:
            return None
        return max(self.danh_sach_so)

    # d. Tìm số nhỏ nhất
    def timMin(self):
        if not self.danh_sach_so:
            return None
        return min(self.danh_sach_so)

    # e. Hiển thị thông tin
    def hienThi(self):
        print(f"Danh sách các số: {self.danh_sach_so}")

# Ví dụ sử dụng:
print("\n--- Lớp Toán Học ---")
# Truyền trực tiếp các số vào constructor
th = ToanHoc(10, 5, 20, 15, -8)

th.hienThi()
print(f"Tổng: {th.tinhTong()}")
print(f"Trung bình: {th.tinhTrungBinh()}")
print(f"Max: {th.timMax()}")
print(f"Min: {th.timMin()}")