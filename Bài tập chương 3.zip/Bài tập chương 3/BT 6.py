# Câu 6: Viết chương trình tạo hai chuỗi (mỗi chuỗi độ dài <= 50),
# tìm chuỗi con chung dài nhất giữa chúng.

def longest_common_substring(s1, s2):
    max_len = 0
    res = ""
    for i in range(len(s1)):
        for j in range(len(s2)):
            k = 0
            while i+k < len(s1) and j+k < len(s2) and s1[i+k] == s2[j+k]:
                k += 1
            if k > max_len:
                max_len = k
                res = s1[i:i+k]
    return res

s1 = input("Nhập chuỗi 1: ")
s2 = input("Nhập chuỗi 2: ")
print("Chuỗi con chung dài nhất:", longest_common_substring(s1, s2))
