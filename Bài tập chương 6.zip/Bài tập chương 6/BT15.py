# Lớp lưu trữ thông tin và tính toán
class HoGiaDinh:
    def __init__(self, so_phong, so_toa, ten_chu_ho, so_kW):
        self.so_phong = so_phong
        self.so_toa = so_toa
        self.ten_chu_ho = ten_chu_ho
        self.so_kW = so_kW
        self.tien_phai_tra = self.tinhTienDien()

    # b. Viết hàm tính tiền điện
    def tinhTienDien(self):
        """Tính tiền điện theo bậc thang."""
        kW = self.so_kW
        tien_dien = 0
        
        # Bậc 1: 100 kW đầu (0 -> 100)
        if kW > 0:
            bac1 = min(kW, 100)
            tien_dien += bac1 * 1450
            kW -= bac1
            
        # Bậc 2: 50 kW tiếp (101 -> 150)
        if kW > 0:
            bac2 = min(kW, 50)
            tien_dien += bac2 * 1750
            kW -= bac2

        # Bậc 3: 100 kW tiếp (151 -> 250)
        if kW > 0:
            bac3 = min(kW, 100)
            tien_dien += bac3 * 2000
            kW -= bac3
            
        # Bậc 4: Từ 250 kW trở lên
        if kW > 0:
            bac4 = kW
            tien_dien += bac4 * 2500
            
        # Tính VAT
        tien_truoc_thue = tien_dien
        thue_VAT = tien_truoc_thue * 0.10
        tong_tien = tien_truoc_thue + thue_VAT
        
        return tong_tien

    def hien_thi_dang_bang(self):
        """Trả về chuỗi định dạng cho bảng (câu c)"""
        print(f"{self.so_toa:<8} | {self.so_phong:<8} | {self.so_kW:<15} | {self.tien_phai_tra:,.0f} VNĐ")

    def __str__(self):
        """Dùng để ghi file (câu d)"""
        return f"Phòng: {self.so_phong}, Chủ hộ: {self.ten_chu_ho}, Tiêu thụ: {self.so_kW} kW, Tiền: {self.tien_phai_tra:,.0f} VNĐ"


# Lớp quản lý chính
class QuanLyChungCuPhucHung:
    def __init__(self):
        self.danh_sach_ho = [] # List các đối tượng HoGiaDinh

    # a. Nhập thông tin (có kiểm tra)
    def nhapThongTin(self):
        print("\n--- (a) Nhập thông tin hộ gia đình ---")
        while True:
            print("Nhập thông tin (nhấn Enter ở 'Số hiệu tòa nhà' để dừng):")
            
            # --- Kiểm tra dữ liệu ---
            so_toa = input("  - Số hiệu tòa nhà: ")
            if not so_toa:
                break
                
            while True:
                so_phong = input("  - Số hiệu phòng: ")
                if so_phong: # Không được rỗng
                    break
                print("  Lỗi: Số phòng không được rỗng.")
                
            while True:
                ten_chu_ho = input("  - Tên chủ hộ: ")
                if ten_chu_ho and ten_chu_ho.replace(" ", "").isalpha(): # Không rỗng và không có ký tự đặc biệt/số
                    break
                print("  Lỗi: Tên chủ hộ không được rỗng và chỉ chứa chữ cái.")
                
            while True:
                try:
                    so_kW = int(input("  - Số kW điện tiêu thụ: "))
                    if so_kW > 0:
                        break
                    print("  Lỗi: Số kW phải lớn hơn 0.")
                except ValueError:
                    print("  Lỗi: Vui lòng nhập một con số.")
            
            # Nếu tất cả hợp lệ, tạo đối tượng
            ho_gd = HoGiaDinh(so_phong, so_toa, ten_chu_ho, so_kW)
            self.danh_sach_ho.append(ho_gd)
            print("--- Đã thêm hộ gia đình ---")

    # c. Hiển thị danh sách
    def hienThiDanhSach(self):
        print("\n" + "="*55)
        print("--- (c) Bảng thống kê tiền điện chung cư ---")
        print(f"{'Tòa nhà':<8} | {'Phòng':<8} | {'Số tiêu thụ (kW)':<15} | {'Tiền phải trả':<15}")
        print("-" * 55)
        
        if not self.danh_sach_ho:
            print("(Chưa có dữ liệu)")
            return
            
        for ho in self.danh_sach_ho:
            ho.hien_thi_dang_bang()
        print("="*55)

    # d. Ghi file (mỗi tòa nhà một tệp)
    def ghiFile(self):
        print("\n--- (d) Ghi thông tin ra tệp theo tòa nhà ---")
        if not self.danh_sach_ho:
            print("Chưa có dữ liệu để ghi.")
            return

        # Lấy danh sách các tòa nhà duy nhất
        cac_toa_nha = set(ho.so_toa for ho in self.danh_sach_ho)
        
        for ten_toa in cac_toa_nha:
            ten_file = f"toa_{ten_toa}.txt"
            try:
                with open(ten_file, 'w', encoding='utf-8') as f:
                    f.write(f"--- DANH SÁCH TIÊU THỤ ĐIỆN TÒA NHÀ {ten_toa} ---\n")
                    for ho in self.danh_sach_ho:
                        if ho.so_toa == ten_toa:
                            f.write(str(ho) + "\n") # Gọi hàm __str__ của HoGiaDinh
                print(f"Đã ghi dữ liệu cho {ten_toa} vào tệp {ten_file}")
            except Exception as e:
                print(f"Lỗi khi ghi tệp {ten_file}: {e}")

# Ví dụ sử dụng:
def main_bai_15():
    qlcc = QuanLyChungCuPhucHung()
    
    # a. Nhập liệu
    qlcc.nhapThongTin()
    
    # c. Hiển thị
    qlcc.hienThiDanhSach()
    
    # d. Ghi file
    qlcc.ghiFile()

main_bai_15() 