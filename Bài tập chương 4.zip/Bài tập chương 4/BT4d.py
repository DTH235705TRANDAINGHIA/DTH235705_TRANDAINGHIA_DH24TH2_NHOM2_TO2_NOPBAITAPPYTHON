def create_binary_string(index, length=10):
    """Tạo chuỗi nhị phân có '1' tại vị trí index (0-based) và '0' ở các vị trí còn lại."""
    # Tạo chuỗi toàn '0'
    s = ['0'] * length
    # Đặt '1' vào vị trí `index` (index 0 là vị trí đầu tiên bên trái)
    s[index] = '1'
    return "".join(s)

# Dùng list comprehension để sinh 10 chuỗi (từ index 0 đến 9)
chuoi_nhi_phan_2 = [create_binary_string(i) for i in range(10)]
print(f"4d) Chuỗi nhị phân 2: {chuoi_nhi_phan_2}")
print("\n")