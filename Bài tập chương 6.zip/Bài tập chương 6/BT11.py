def bai_11_quan_ly_san_pham():
    ten_file = "products.txt"

    # Chức năng nhập (nối đuôi vào file)
    print("--- Nhập thông tin sản phẩm ---")
    while True:
        ma_sp = input("Nhập Mã sản phẩm (nhấn Enter để dừng): ")
        if not ma_sp:
            break
        ten_sp = input("Nhập Tên sản phẩm: ")
        don_gia = input("Nhập Đơn giá: ")
        
        # Định dạng chuỗi theo yêu cầu
        chuoi_luu = f"{ma_sp};{ten_sp};{don_gia}\n"
        
        # Ghi nối đuôi vào file
        try:
            with open(ten_file, 'a', encoding='utf-8') as f:
                f.write(chuoi_luu)
            print("Đã lưu sản phẩm.")
        except Exception as e:
            print(f"Lỗi khi lưu file: {e}")

    # Chức năng (a): Xuất danh sách
    print("\n--- (a) Xuất danh sách sản phẩm từ File ---")
    try:
        with open(ten_file, 'r', encoding='utf-8') as f:
            print(f"{'Mã SP':<10} | {'Tên SP':<20} | {'Đơn giá':<10}")
            print("-" * 44)
            for dong in f:
                # Tách dữ liệu bằng dấu ;
                parts = dong.strip().split(';')
                if len(parts) == 3:
                    ma, ten, gia = parts
                    print(f"{ma:<10} | {ten:<20} | {gia:<10}")
    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy tệp {ten_file}")
    except Exception as e:
        print(f"Lỗi khi đọc file: {e}")

# Ví dụ sử dụng:
# bai_11_quan_ly_san_pham()

