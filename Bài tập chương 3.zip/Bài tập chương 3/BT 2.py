# Câu 2: Viết chương trình nhập vào 1 chuỗi, sau đó in ra chiều dài chuỗi,
# ký tự đầu, ký tự cuối, và các ký tự từ vị trí i đến j (i, j nhập từ bàn phím).

s = input("Nhập chuỗi: ")
print("Chiều dài chuỗi:", len(s))
print("Ký tự đầu:", s[0])
print("Ký tự cuối:", s[-1])

i = int(input("Nhập vị trí i: "))
j = int(input("Nhập vị trí j: "))
print("Các ký tự từ vị trí", i, "đến", j, "là:", s[i:j+1])
