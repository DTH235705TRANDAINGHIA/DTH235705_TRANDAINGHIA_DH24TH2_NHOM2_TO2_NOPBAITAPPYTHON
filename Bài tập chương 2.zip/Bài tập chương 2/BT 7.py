# Cách A: nhập 3 số n1,n2,n3 rồi in n1+n2+n3
def tong_ba_so(n1, n2, n3):
    return n1 + n2 + n3

# Cách B: nhập 1 số n rồi tính n + n^2 + n^3
def n_cong_n2_n3(n):
    return n + n**2 + n**3


