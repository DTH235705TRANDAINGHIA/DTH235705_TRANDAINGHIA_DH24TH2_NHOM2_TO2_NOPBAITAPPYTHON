def tien_sau_18_thang(X, lai_thang=0.6):
    lai_6thang = lai_thang/100 * 6
    so_ky = 18//6
    return X * (1 + lai_6thang)**so_ky

# VD:
print(tien_sau_18_thang(1000000))  # kết quả cho X = 1_000_000
