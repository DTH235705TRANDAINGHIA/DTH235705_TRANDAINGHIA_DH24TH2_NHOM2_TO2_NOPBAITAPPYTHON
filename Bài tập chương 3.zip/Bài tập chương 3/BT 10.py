def kiem_tra_email(email):
    if '@' in email and '.' in email:
        phan1 = email.split('@')
        if len(phan1) == 2:
            ten, mien = phan1
            phan2 = mien.split('.')
            if len(phan2) == 2 and ten and phan2[0] and phan2[1]:
                print("Email hợp lệ")
                return
    print("Email không hợp lệ")

# Ví dụ:
email = input("Nhập địa chỉ email: ")
kiem_tra_email(email)
