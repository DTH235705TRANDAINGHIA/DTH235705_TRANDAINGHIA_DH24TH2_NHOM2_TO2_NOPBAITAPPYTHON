def sort_dict_by_value(my_dict):
    """
    Sắp xếp từ điển theo giá trị (value) và hiển thị kết quả.
    """
    print(f"9) Từ điển ban đầu: {my_dict}")
    
    # Sắp xếp TĂNG DẦN theo giá trị (value)
    # key=lambda item: item[1] lấy phần tử thứ 2 (value) của mỗi cặp (key, value)
    sorted_items_asc = sorted(my_dict.items(), key=lambda item: item[1])
    
    # Tạo lại từ điển mới từ kết quả đã sắp xếp
    dict_asc = dict(sorted_items_asc)

    print(f"  - Sắp xếp **TĂNG DẦN** theo giá trị: {dict_asc}")

    # Sắp xếp GIẢM DẦN theo giá trị (value)
    sorted_items_desc = sorted(my_dict.items(), key=lambda item: item[1], reverse=True)
    dict_desc = dict(sorted_items_desc)

    print(f"  - Sắp xếp **GIẢM DẦN** theo giá trị: {dict_desc}")

# Ví dụ sử dụng:
data_dict = {'apple': 50, 'banana': 10, 'cherry': 30, 'date': 20}
sort_dict_by_value(data_dict)