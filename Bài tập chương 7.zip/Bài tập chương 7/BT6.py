from tkinter import *
from tkinter import messagebox

def doi_mat_khau():
    old_pass = entry_old.get()
    new_pass = entry_new.get()
    re_pass = entry_re.get()

    if new_pass == old_pass:
        messagebox.showwarning("Cảnh báo", "Bạn không được dùng mật khẩu cũ")
    elif new_pass != re_pass:
        messagebox.showwarning("Cảnh báo", "Bạn phải nhập lại mật khẩu mới giống nhau")
    else:
        messagebox.showinfo("Thành công", "Đổi mật khẩu thành công!")
        entry_old.delete(0, END)
        entry_new.delete(0, END)
        entry_re.delete(0, END)

def thoat():
    root.destroy()

root = Tk()
root.title("Enter New Password")

Label(root, text="Old Password:").grid(row=0, column=0, sticky=W, padx=10, pady=5)
entry_old = Entry(root, show="*")
entry_old.grid(row=0, column=1, padx=10, pady=5)

Label(root, text="New Password:").grid(row=1, column=0, sticky=W, padx=10, pady=5)
entry_new = Entry(root, show="*")
entry_new.grid(row=1, column=1, padx=10, pady=5)

Label(root, text="Enter New Password Again:").grid(row=2, column=0, sticky=W, padx=10, pady=5)
entry_re = Entry(root, show="*")
entry_re.grid(row=2, column=1, padx=10, pady=5)

frame_btn = Frame(root)
frame_btn.grid(row=3, column=0, columnspan=2, pady=10)

Button(frame_btn, text="OK", width=10, command=doi_mat_khau).pack(side=LEFT, padx=10)
Button(frame_btn, text="Cancel", width=10, command=thoat).pack(side=LEFT, padx=10)

root.mainloop()
#chương trình thay đổi mật khẩu