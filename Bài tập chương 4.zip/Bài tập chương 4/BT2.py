def is_prime(num):
    """Kiểm tra một số có phải là số nguyên tố không."""
    if num < 2:
        return False
    # Chỉ cần kiểm tra đến căn bậc hai của num
    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            return False
    return True

def GenPrime(n):
    """
    Generator sinh ra n số nguyên tố đầu tiên.
    """
    if n <= 0:
        return
        
    count = 0
    num = 2 # Bắt đầu từ số nguyên tố nhỏ nhất
    while count < n:
        if is_prime(num):
            yield num
            count += 1
        num += 1

# Ví dụ sử dụng:
n_value = 10
print(f"2) {n_value} số nguyên tố đầu tiên: ", end="")
for prime in GenPrime(n_value):
    print(prime, end=", ")
print("\n")