# Lớp cơ sở (Base class)
class DaGiac:
    def __init__(self, so_canh):
        self.so_canh = so_canh
        print(f"Khởi tạo một Đa Giác có {self.so_canh} cạnh.")

    def inputInfo(self):
        print("Nhập thông tin cho Đa Giác...")
        # (Lớp cơ sở này có thể để trống hoặc nhập thuộc tính chung)

    def tinhChuVi(self):
        raise NotImplementedError("Lớp con phải định nghĩa phương thức này.")

    def tinhDienTich(self):
        raise NotImplementedError("Lớp con phải định nghĩa phương thức này.")

# Lớp con 1
class HinhBinhHanh(DaGiac):
    def __init__(self):
        super().__init__(4) # Hình bình hành luôn có 4 cạnh
        self.canh_day = 0
        self.canh_ben = 0
        self.chieu_cao = 0

    def inputInfo(self):
        print("\n--- Nhập thông tin Hình Bình Hành ---")
        self.canh_day = float(input("Nhập độ dài cạnh đáy: "))
        self.canh_ben = float(input("Nhập độ dài cạnh bên: "))
        self.chieu_cao = float(input("Nhập độ dài chiều cao (tương ứng cạnh đáy): "))

    def tinhChuVi(self):
        return (self.canh_day + self.canh_ben) * 2

    def tinhDienTich(self):
        return self.canh_day * self.chieu_cao

# Lớp con 2
class HinhChuNhat(HinhBinhHanh):
    def inputInfo(self):
        print("\n--- Nhập thông tin Hình Chữ Nhật ---")
        self.canh_day = float(input("Nhập chiều dài: "))
        self.canh_ben = float(input("Nhập chiều rộng: "))
        # Trong hình chữ nhật, chiều cao bằng chiều rộng
        self.chieu_cao = self.canh_ben

    # tinhChuVi() được kế thừa nguyên vẹn từ HinhBinhHanh
    
    # tinhDienTich() có thể override cho rõ ràng, dù công thức HBH vẫn đúng
    def tinhDienTich(self):
        return self.canh_day * self.canh_ben

# Lớp con 3
class HinhVuong(HinhChuNhat):
    def inputInfo(self):
        print("\n--- Nhập thông tin Hình Vuông ---")
        canh = float(input("Nhập độ dài cạnh: "))
        self.canh_day = canh
        self.canh_ben = canh
        self.chieu_cao = canh
    
    # Cả tinhChuVi() và tinhDienTich() đều được kế thừa
    # và hoạt động chính xác.

# Ví dụ sử dụng:
print("--- Kế thừa Hình Học ---")

# Hình chữ nhật
hcn_kethua = HinhChuNhat()
hcn_kethua.inputInfo()
print(f"Chu vi HCN: {hcn_kethua.tinhChuVi()}")
print(f"Diện tích HCN: {hcn_kethua.tinhDienTich()}")

# Hình vuông
hv_kethua = HinhVuong()
hv_kethua.inputInfo()
print(f"Chu vi HV: {hv_kethua.tinhChuVi()}")
print(f"Diện tích HV: {hv_kethua.tinhDienTich()}")