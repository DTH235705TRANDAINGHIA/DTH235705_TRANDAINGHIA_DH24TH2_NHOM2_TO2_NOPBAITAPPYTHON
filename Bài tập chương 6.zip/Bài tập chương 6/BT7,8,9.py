def bai_7_8_9():
    ten_file = "data71.txt"

    # --- Câu 7: Ghi các số từ 1 đến 10 ---
    try:
        with open(ten_file, 'w', encoding='utf-8') as f:
            for i in range(1, 11):
                f.write(f"{i}\n")
        print(f"Đã ghi 10 số vào {ten_file}.")
    except Exception as e:
        print(f"Lỗi khi ghi tệp (Câu 7): {e}")

    # --- Câu 8: Đọc và hiển thị ---
    print("\n--- Câu 8: Đọc tệp data71.txt ---")
    try:
        with open(ten_file, 'r', encoding='utf-8') as f:
            noi_dung = f.read()
            print(noi_dung)
    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy tệp {ten_file} (Câu 8)")
    
    # --- Câu 9: Tính tổng và ghi nối vào cuối ---
    try:
        tong = 0
        # Đọc file để tính tổng
        with open(ten_file, 'r', encoding='utf-8') as f:
            for dong in f:
                try:
                    so = int(dong.strip())
                    tong += so
                except ValueError:
                    continue # Bỏ qua các dòng không phải là số
        
        print(f"Tổng các số trong tệp: {tong}")

        # Mở file ở chế độ 'a' để ghi nối tổng
        with open(ten_file, 'a', encoding='utf-8') as f:
            f.write(f"\nTong cac so la: {tong}\n")
        print("Đã ghi tổng vào cuối tệp.")
        
    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy tệp {ten_file} (Câu 9)")
    except Exception as e:
        print(f"Lỗi (Câu 9): {e}")
