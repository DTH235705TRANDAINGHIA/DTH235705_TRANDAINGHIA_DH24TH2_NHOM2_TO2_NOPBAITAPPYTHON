import math

# a)
def in_tong_1_den_n(n):
    print("Tổng 1..n =", n*(n+1)//2)

# b)
def kiem_tra_cung_nguyen_to(m, n):
    if math.gcd(m, n) == 1:
        print("Hai số này là nguyên tố cùng nhau")
    else:
        print("Hai số này không là nguyên tố cùng nhau")

# c)
def chuyen_giay(s):
    h = s // 3600
    m = (s % 3600) // 60
    sec = s % 60
    print(f"{s} giây = {h} giờ, {m} phút, {sec} giây")

# d)
def tri_tuyet_doi(a, b):
    return abs(a - b)

# Ví dụ:
in_tong_1_den_n(10)
kiem_tra_cung_nguyen_to(14,15)
chuyen_giay(3665)
print(tri_tuyet_doi(3.5, -1.2))
