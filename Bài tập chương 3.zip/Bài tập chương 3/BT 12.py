chuoi = input("Nhập chuỗi: ")

in_hoa = sum(c.isupper() for c in chuoi)
in_thuong = sum(c.islower() for c in chuoi)
chu_so = sum(c.isdigit() for c in chuoi)
dac_biet = sum(not c.isalnum() and not c.isspace() for c in chuoi)
khoang_trang = sum(c.isspace() for c in chuoi)

nguyen_am = sum(c.lower() in 'aeiou' for c in chuoi if c.isalpha())
phu_am = sum(c.isalpha() for c in chuoi) - nguyen_am

print("Chữ IN HOA:", in_hoa)
print("Chữ thường:", in_thuong)
print("Chữ số:", chu_so)
print("Ký tự đặc biệt:", dac_biet)
print("Khoảng trắng:", khoang_trang)
print("Nguyên âm:", nguyen_am)
print("Phụ âm:", phu_am)
