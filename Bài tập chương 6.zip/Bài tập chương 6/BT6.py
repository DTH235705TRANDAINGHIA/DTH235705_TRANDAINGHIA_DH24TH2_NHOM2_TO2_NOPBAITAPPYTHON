from collections import Counter

def tinh_tan_so_tu(ten_file):
    """
    Đọc tệp, chuyển về chữ thường, và đếm tần suất các từ.
    """
    try:
        with open(ten_file, 'r', encoding='utf-8') as f:
            noi_dung = f.read()
            
            # Xử lý: chuyển về chữ thường và tách từ
            tu_ngu = noi_dung.lower().split()
            
            # Dùng Counter để đếm
            tan_so = Counter(tu_ngu)
            
            print(f"--- Tần số từ trong tệp {ten_file} ---")
            for tu, so_lan in tan_so.items():
                print(f"'{tu}': {so_lan}")
                
    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy tệp {ten_file}")
