import math
import cmath

def giai_pt_bac2(a, b, c):
    if a == 0:
        return "a phải khác 0 (không phải phương trình bậc 2)"
    d = b*b - 4*a*c
    if d >= 0:
        x1 = (-b + math.sqrt(d)) / (2*a)
        x2 = (-b - math.sqrt(d)) / (2*a)
        return (x1, x2)
    else:
        x1 = (-b + cmath.sqrt(d)) / (2*a)
        x2 = (-b - cmath.sqrt(d)) / (2*a)
        return (x1, x2)

