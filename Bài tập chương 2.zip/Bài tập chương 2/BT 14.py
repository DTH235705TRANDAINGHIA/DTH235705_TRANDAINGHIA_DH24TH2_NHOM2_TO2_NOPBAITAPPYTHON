def ngay_ve(start_day="thứ tư", nights=137):
    days = ["thứ hai","thứ ba","thứ tư","thứ năm","thứ sáu","thứ bảy","chủ nhật"]
    idx = days.index(start_day)
    new_idx = (idx + nights) % 7
    return days[new_idx]

print(ngay_ve("thứ tư", 137))  # kết quả
