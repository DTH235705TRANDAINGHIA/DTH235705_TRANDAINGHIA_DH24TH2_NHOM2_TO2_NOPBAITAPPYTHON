def bai_10_ghi_nguoi_dung():
    ten_file = "data72.txt"
    
    # Nhập thông tin
    ho_ten = input("Nhập họ và tên: ")
    tuoi = input("Nhập tuổi: ")
    
    # Ghi vào tệp
    try:
        # Dùng 'w' để ghi mới, 'a' để thêm vào
        with open(ten_file, 'w', encoding='utf-8') as f:
            f.write(f"Ho ten: {ho_ten}\n")
            f.write(f"Tuoi: {tuoi}\n")
        print(f"Đã ghi thông tin vào {ten_file}.")
    except Exception as e:
        print(f"Lỗi khi ghi tệp: {e}")
