from tkinter import *
from tkinter import messagebox

def btn_click(item):
    current = str(entry_text.get())
    entry_text.set(current + str(item))

def btn_clear():
    entry_text.set("")

def btn_equal():
    try:
        result = str(eval(entry_text.get()))
        entry_text.set(result)
    except:
        messagebox.showerror("Lỗi", "Phép tính không hợp lệ!")

root = Tk()
root.title("Calculator")

entry_text = StringVar()
entry = Entry(root, textvariable=entry_text, font=('Arial', 18), justify='right', bd=5)
entry.grid(row=0, column=0, columnspan=4, ipadx=8, ipady=8, padx=5, pady=5)

# Các nút số
buttons = [
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    '0', '.', '=', '+'
]

row_val = 1
col_val = 0

for button in buttons:
    Button(root, text=button, width=5, height=2, font=('Arial', 14),
           command=lambda b=button: btn_click(b) if b != '=' else btn_equal()).grid(row=row_val, column=col_val, padx=5, pady=5)
    col_val += 1
    if col_val > 3:
        col_val = 0
        row_val += 1

# Nút Clear
Button(root, text="Clr", width=23, height=2, font=('Arial', 12), command=btn_clear).grid(row=row_val+1, column=0, columnspan=4, pady=5)

root.mainloop()
#chương trình máy tính