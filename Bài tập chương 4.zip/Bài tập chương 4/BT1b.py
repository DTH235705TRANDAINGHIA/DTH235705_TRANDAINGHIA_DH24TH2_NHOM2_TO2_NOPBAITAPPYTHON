def generate_n_square_numbers(n):
    """
    Sinh ra n số chính phương đầu tiên, bắt đầu từ 0^2.
    """
    if n <= 0:
        return
    
    i = 0
    count = 0
    while count < n:
        yield i * i
        i += 1
        count += 1

# Ví dụ sử dụng:
n_value = 8
print(f"1b) {n_value} số chính phương đầu tiên: ", end="")
for num in generate_n_square_numbers(n_value):
    print(num, end=", ")
print("\n")