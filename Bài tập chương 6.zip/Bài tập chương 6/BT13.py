import json

# Lớp đại diện cho 1 sản phẩm
class SanPham:
    def __init__(self, ma, ten, don_gia):
        self.ma = ma
        self.ten = ten
        self.don_gia = don_gia

    def hien_thi(self):
        print(f"    - SP: {self.ma} | Tên: {self.ten} | Giá: {self.don_gia:,.0f}")

# Lớp đại diện cho 1 danh mục (chứa nhiều sản phẩm)
class DanhMuc:
    def __init__(self, ma_dm, ten_dm):
        self.ma_dm = ma_dm
        self.ten_dm = ten_dm
        self.danh_sach_sp = [] # Danh sách các đối tượng SanPham

    def them_sp(self):
        print(f"--- Thêm sản phẩm vào DM '{self.ten_dm}' ---")
        ma = input("  Nhập mã sản phẩm: ")
        ten = input("  Nhập tên sản phẩm: ")
        don_gia = float(input("  Nhập đơn giá: "))
        self.danh_sach_sp.append(SanPham(ma, ten, don_gia))
        print("Đã thêm sản phẩm.")

    def hien_thi(self):
        print(f"\n--- Danh mục: {self.ten_dm} (Mã: {self.ma_dm}) ---")
        if not self.danh_sach_sp:
            print("  (Chưa có sản phẩm nào)")
            return
        for sp in self.danh_sach_sp:
            sp.hien_thi()

# Lớp chính quản lý các danh mục và file
class QuanLyCuaHang:
    def __init__(self, ten_file):
        self.danh_sach_dm = [] # Danh sách các đối tượng DanhMuc
        self.ten_file = ten_file
        self.doc_file() # Tải dữ liệu khi khởi tạo

    def them_dm(self):
        print("\n--- Thêm Danh Mục Mới ---")
        ma_dm = input("  Nhập mã danh mục: ")
        ten_dm = input("  Nhập tên danh mục: ")
        self.danh_sach_dm.append(DanhMuc(ma_dm, ten_dm))
        print("Đã thêm danh mục.")

    def tim_dm(self, ma_dm):
        for dm in self.danh_sach_dm:
            if dm.ma_dm == ma_dm:
                return dm
        return None

    def quan_ly_san_pham_trong_dm(self):
        ma_dm = input("Nhập mã danh mục bạn muốn quản lý SP: ")
        dm = self.tim_dm(ma_dm)
        if dm:
            dm.hien_thi()
            dm.them_sp() # Mở rộng: có thể thêm menu (thêm/sửa/xóa SP)
        else:
            print("Không tìm thấy danh mục.")

    def hien_thi_tat_ca(self):
        print("\n" + "="*30)
        print("--- TOÀN BỘ DANH MỤC VÀ SẢN PHẨM ---")
        if not self.danh_sach_dm:
            print("(Chưa có dữ liệu)")
            return
        for dm in self.danh_sach_dm:
            dm.hien_thi()
        print("="*30)

    # Lưu và Đọc File (dùng JSON để đơn giản hóa)
    def luu_file(self):
        try:
            # Chuyển đổi đối tượng lồng nhau thành dict
            data = []
            for dm in self.danh_sach_dm:
                dm_data = dm.__dict__.copy()
                dm_data['danh_sach_sp'] = [sp.__dict__ for sp in dm.danh_sach_sp]
                data.append(dm_data)
            
            with open(self.ten_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            print(f"Đã lưu dữ liệu vào {self.ten_file}")
        except Exception as e:
            print(f"Lỗi khi lưu file: {e}")

    def doc_file(self):
        try:
            with open(self.ten_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
                # Khởi tạo lại đối tượng từ dữ liệu dict
                self.danh_sach_dm = []
                for dm_data in data:
                    dm = DanhMuc(dm_data['ma_dm'], dm_data['ten_dm'])
                    for sp_data in dm_data['danh_sach_sp']:
                        sp = SanPham(sp_data['ma'], sp_data['ten'], sp_data['don_gia'])
                        dm.danh_sach_sp.append(sp)
                    self.danh_sach_dm.append(dm)
            print(f"Đã tải dữ liệu từ {self.ten_file}")
        except FileNotFoundError:
            print(f"Không tìm thấy tệp {self.ten_file}. Bắt đầu với danh sách rỗng.")
        except Exception as e:
            print(f"Lỗi khi đọc file: {e}")

# Menu chính (ví dụ đơn giản)
def main_bai_13():
    qlch = QuanLyCuaHang("cuahang_data.json")
    
    while True:
        print("\n--- MENU QUẢN LÝ (BÀI 13) ---")
        print("1. Thêm danh mục mới")
        print("2. Thêm sản phẩm vào danh mục")
        print("3. Hiển thị tất cả")
        print("4. Lưu dữ liệu")
        print("0. Thoát")
        
        lua_chon = input("Chọn chức năng: ")
        
        if lua_chon == '1':
            qlch.them_dm()
        elif lua_chon == '2':
            qlch.quan_ly_san_pham_trong_dm()
        elif lua_chon == '3':
            qlch.hien_thi_tat_ca()
        elif lua_chon == '4':
            qlch.luu_file()
        elif lua_chon == '0':
            qlch.luu_file() # Tự động lưu khi thoát
            break

# Ví dụ sử dụng:
# main_bai_13()