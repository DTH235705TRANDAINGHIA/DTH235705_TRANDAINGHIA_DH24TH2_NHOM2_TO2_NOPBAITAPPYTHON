import random

# List để minh họa cho Câu 6
list_for_6 = []

def a_random_list(n):
    """a. Viết lệnh khởi tạo ngẫu nhiên n phần tử cho list."""
    global list_for_6
    # Tạo list n phần tử ngẫu nhiên (ví dụ: số nguyên từ 1 đến 100)
    list_for_6 = [random.randint(1, 100) for _ in range(n)]
    print(f"6a) List ngẫu nhiên ({n} phần tử): {list_for_6}")

def b_remove_element(k):
    """b. Gọi k là một số nhập từ bàn phím, hãy xóa tất cả các phần tử có giá trị k tồn tại trong list."""
    global list_for_6
    original_length = len(list_for_6)
    
    # Dùng list comprehension để tạo list mới KHÔNG chứa k
    list_for_6 = [x for x in list_for_6 if x != k]
    
    removed_count = original_length - len(list_for_6)
    print(f"6b) Đã xóa {removed_count} phần tử có giá trị '{k}'. List mới: {list_for_6}")

def c_check_palindrome():
    """c. Kiểm tra list có đối xứng hay không."""
    # List đối xứng là list đọc xuôi và đọc ngược giống nhau.
    is_palindrome = list_for_6 == list_for_6[::-1]
    
    print(f"6c) List {list_for_6} có đối xứng không? **{is_palindrome}**")
    return is_palindrome

# Ví dụ minh họa Câu 6
print("--- 6. Thực thi các chức năng nâng cao của List ---")
a_random_list(15)
b_remove_element(list_for_6[2]) # Xóa phần tử thứ 3 (để minh họa)

# Thiết lập list đối xứng để kiểm tra
list_for_6 = [1, 2, 3, 2, 1]
print(f"Thiết lập list: {list_for_6}")
c_check_palindrome()

list_for_6 = [1, 2, 3, 4]
print(f"Thiết lập list: {list_for_6}")
c_check_palindrome()
print("\n")