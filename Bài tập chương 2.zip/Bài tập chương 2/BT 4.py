def la_nam_nhuan(y):
    return (y % 4 == 0 and y % 100 != 0) or (y % 400 == 0)

def so_ngay_trong_thang(thang, nam=None):
    if thang in (1,3,5,7,8,10,12):
        return 31
    elif thang in (4,6,9,11):
        return 30
    elif thang == 2:
        if nam is None:
            raise ValueError("Cần nhập năm để biết tháng 2 có 28 hay 29 ngày")
        return 29 if la_nam_nhuan(nam) else 28
    else:
        raise ValueError("Tháng không hợp lệ (1-12)")
