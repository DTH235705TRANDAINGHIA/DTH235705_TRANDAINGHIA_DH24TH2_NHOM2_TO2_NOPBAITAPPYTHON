def dem_so_lieu_tep(ten_file):
    """
    Đếm số dòng, số từ và số ký tự trong tệp.
    """
    try:
        with open(ten_file, 'r', encoding='utf-8') as f:
            noi_dung = f.read()
            
            # Đưa con trỏ về đầu file để đọc lại cho việc đếm dòng
            f.seek(0)
            so_dong = len(f.readlines())
            
            so_ky_tu = len(noi_dung)
            so_tu = len(noi_dung.split())
            
            print(f"--- Thống kê tệp {ten_file} ---")
            print(f"Số dòng: {so_dong}")
            print(f"Số từ: {so_tu}")
            print(f"Số ký tự: {so_ky_tu}")
            
    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy tệp {ten_file}")

