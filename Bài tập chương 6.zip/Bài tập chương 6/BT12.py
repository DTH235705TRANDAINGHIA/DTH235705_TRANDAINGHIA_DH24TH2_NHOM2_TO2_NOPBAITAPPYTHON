def bai_12_xu_ly_so():
    ten_file = "data_so.txt"
    # Giả sử tệp data_so.txt có nội dung như trong hình:
    # 5,6,8,9,-5
    # -9,5,4,7,8
    # 6,7,8,8,3,6,46,7,2,-6,-7

    danh_sach_cac_dong = []

    # a. Đọc file, mỗi dòng thành 1 list, xuất ra màn hình
    print("--- (a) Đọc dữ liệu từ tệp ---")
    try:
        with open(ten_file, 'r', encoding='utf-8') as f:
            for dong in f:
                dong_sach = dong.strip()
                if dong_sach:
                    # Tách các số bằng dấu phẩy và chuyển sang kiểu int
                    list_so = [int(so) for so in dong_sach.split(',')]
                    danh_sach_cac_dong.append(list_so)
                    
        # Xuất ra màn hình
        print("Dữ liệu đã đọc (list của các list):")
        for dong_list in danh_sach_cac_dong:
            print(dong_list)

    except FileNotFoundError:
        print(f"Lỗi: Không tìm thấy tệp {ten_file}")
        return
    except Exception as e:
        print(f"Lỗi khi đọc file: {e}")
        return

    # b. Xuất các số âm
    print("\n--- (b) Các số âm tìm thấy ---")
    tim_thay_so_am = False
    for dong_list in danh_sach_cac_dong:
        for so in dong_list:
            if so < 0:
                print(so, end=" ")
                tim_thay_so_am = True
    
    if not tim_thay_so_am:
        print("Không tìm thấy số âm nào.")
    print() # Xuống dòng

# Ví dụ sử dụng:
# (Hãy tạo tệp "data_so.txt" trước khi chạy)
# bai_12_xu_ly_so()