class NhanVien:
    def __init__(self):
        self.ten = ""
        self.tuoi = 0
        self.dia_chi = ""
        self.tien_luong = 0.0
        self.tong_so_gio_lam = 0

    # a. InputInfo
    def inputInfo(self):
        print("\n--- Nhập thông tin Nhân Viên ---")
        self.ten = input("Nhập tên: ")
        self.tuoi = int(input("Nhập tuổi: "))
        self.dia_chi = input("Nhập địa chỉ: ")
        self.tien_luong = float(input("Nhập tiền lương: "))
        self.tong_so_gio_lam = int(input("Nhập tổng số giờ làm: "))

    # b. PrintInfo
    def printInfo(self):
        print("\n--- Thông tin Nhân Viên ---")
        print(f"Tên: {self.ten}, Tuổi: {self.tuoi}")
        print(f"Địa chỉ: {self.dia_chi}")
        print(f"Tiền lương: {self.tien_luong:,.0f} VNĐ")
        print(f"Tổng số giờ làm: {self.tong_so_gio_lam} giờ")
        
    # c. tinhThuong
    def tinhThuong(self):
        thuong = 0
        if self.tong_so_gio_lam >= 200:
            thuong = self.tien_luong * 0.20
        elif self.tong_so_gio_lam >= 100: # Python sẽ tự hiểu là < 200
            thuong = self.tien_luong * 0.10
        # else: thuong = 0 (đã khởi tạo)
            
        print(f"Tiền thưởng của nhân viên {self.ten} là: {thuong:,.0f} VNĐ")
        return thuong

# Ví dụ sử dụng:
print("\n--- Lớp Nhân Viên ---")
nv1 = NhanVien()
nv1.inputInfo()
nv1.printInfo()
nv1.tinhThuong()

# Ví dụ 2
nv2 = NhanVien()
nv2.ten = "B"
nv2.tien_luong = 20000000
nv2.tong_so_gio_lam = 150
nv2.printInfo()
nv2.tinhThuong()